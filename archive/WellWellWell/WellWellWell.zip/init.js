loadroom(player.room)

let roomtick = Date.now()
let game = setInterval(gameloop, 10)