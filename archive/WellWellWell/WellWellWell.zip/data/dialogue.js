let dialogue = {
    "test": [
        {
            "name": "You",
            "text": "I know where you live."
        }
    ],
    "introtext": [
        {
            "name": "You",
            "text": "It's the wishing well...\n\nI need to make a wish...\n\nI can't tell anyone, or it won't come true..."
        },
        {
            "name": "You",
            "text": "...............\nShit, I don't have any cash.\nFor fucks sake.\n\nFetch quest shit like this never goes well."
        },
    ],
    "bimble": [
        {
            "name": "Bimble",
            "text": "Cannonically, I'm a maths teacher.",
            "audio": "sfx/maow.mp3"
        },
    ],
    "heckler": [
        {
            "name": "Heckler",
            "text": "wadshada...\n...\nMy dude, I hear you come through th- the offscreen fireplace..."
        },
        {
            "name": "You",
            "text": "I do what I fucking like.\nI just wanna get soME FUCKING COINS."
        },
        {
            "name": "Heckler",
            "text": "At least knock."
        },
        {
            "name": "You",
            "text": "No, fuck off."
        },
        {
            "name": "You",
            "text": "Suck a cock."
        },
        {
            "name": "Heckler",
            "text": "No, I don't want to."
        },
        {
            "name": "You",
            "text": "Why?"
        },
        {
            "name": "Heckler",
            "text": "Cuz I'm...\nCuz...\nC- I don't want to."
        },
        {
            "name": "You",
            "text": "Haha, why?"
        },
        {
            "name": "Heckler",
            "text": "Hahahaha."
        },
        {
            "name": "You",
            "text": "Why though?"
        },
        {
            "name": "Heckler",
            "text": "I don't like cock."
        },
        {
            "name": "You",
            "text": "Why?"
        },
        {
            "name": "Heckler",
            "text": "Cuz I don't."
        },
        {
            "name": "You",
            "text": "Are you afraid?"
        },
        {
            "name": "Heckler",
            "text": "Yes, I'm afraid."
        },
        {
            "name": "You",
            "text": "Daaaaammnnnn, you're afraid!\nWhy are you afraid?"
        },
        {
            "name": "Heckler",
            "text": "Because I'm scared of the cock!"
        },
        {
            "name": "You",
            "text": "That's a skill issue."
        },
        {
            "name": "Heckler",
            "text": "And anyway, get the fuck out of my room!"
        },
        {
            "name": "You",
            "text": "Fuck you!"
        },
        {
            "name": "Heckler",
            "text": "Get the fuck out of my room!"
        },
        {
            "name": "You",
            "text": "Fuck you!"
        },
        {
            "name": "Heckler",
            "text": "Fuck you too!\nGet the fuck out of my room!"
        },
    ],
}