let credits = `
<div style="height: 512px;"></div>
<div>
    <br>
    <h1>Well Well Well...</h1>
    <br>
    <p>Created by</p>
    <h3>Dexter M. S. Taylor</h3>
    <h3>Jacob A. G. Taylor</h3>
    <br>
    <p>Art</p>
    <h3>Dexter M. S. Taylor</h3>
    <br>
    <p>Programming</p>
    <h3>Jacob A. G. Taylor</h3>
    <br>
</div>
`